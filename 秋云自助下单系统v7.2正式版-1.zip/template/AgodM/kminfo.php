
<?php
include 'head2.php'
?>
<?php


$id = intval($_GET['id']);
if (md5($id . SYS_KEY . $id) !== $_GET['skey']) {
    exit("<script language='javascript'>alert('验证失败');history.go(-1);</script>");
}
$row = $DB->getRow("SELECT * FROM pre_orders WHERE id='$id' LIMIT 1");
if (!$row) {
    exit("<script language='javascript'>alert('当前订单不存在！');history.go(-1);</script>");
}
$tool = $DB->getRow("SELECT * FROM pre_tools WHERE tid='{$row['tid']}' LIMIT 1");
if ($tool['is_curl'] != 4 && $row['djzt'] != 3) {
    exit("<script language='javascript'>alert('非发卡类商品！');history.go(-1);</script>");
}
$count = ($tool['value'] > 1 ? $tool['value'] : 1) * $row['value'];
$rs = $DB->query("SELECT * FROM pre_faka WHERE tid='{$row['tid']}' AND orderid='$id' ORDER BY kid ASC LIMIT {$count}");
$rs2 = $DB->query("SELECT * FROM pre_faka WHERE tid='{$row['tid']}' AND orderid='$id' ORDER BY kid ASC LIMIT {$count}");

$kmdata = '';
$kmdata2 = '';
$rcount = 0;

while ($res = $rs->fetch()) {
    $rcount++;
    if (!empty($res['pw'])) {
        $kmdata .= '卡号：' . $res['km'] . ' 密码：' . $res['pw'] . "\r\n";
        $kmdata2 .= '卡号：' . $res['km'] . ' 密码：' . $res['pw'] . "<br>";
    } else {
        $kmdata .= $res['km'] . "\r\n";
        $kmdata2 .= $res['km'] . "<br>";
    }
}



if (strlen($kmdata) > 2) {
    $kmdata = substr($kmdata, 0, -2);
}


?>
<div id="main-wrapper">

            <div class="content-body">
                <div class="w-100 header">
                    <a class="back" href="javascript:history.go(-1)">
                        <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABcAAAAlCAMAAACeRoI0AAAANlBMVEX///7///7///7///7///7///7///7///7///7///7///7///7///7///7///7///7///7///5LoXkPAAAAEXRSTlMAAwQMLi9FT2Nkmamqwsfq/lhk4vUAAABRSURBVHhe7ckxAoAgDMXQFhVRQdv7X9YKLvi7uJMxj6DI5JUks7tVK+A2CLhru7+vBfbYM3Ud2jqn/of8QvkA/4YBspIHstlAkGQDoW2E+PANpJ8STttpJgMAAAAASUVORK5CYII=" class="hide_left">
                    </a>
                    订单查询
                </div>
                <div class="order-banner">
                    <div class="container">
                        <div class="row pl-2 pr-2" style="background: #3352f5;">
                            <div class="col-md-12 title pt-3 pb-3">
                                <h5 class="text-white"> <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKoAAABuCAYAAAC3D4ggAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAA3ZpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMy1jMDExIDY2LjE0NTY2MSwgMjAxMi8wMi8wNi0xNDo1NjoyNyAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDphOGE2NjgwZC01YjQ5LWQ1NGQtOTU5Ny0yNTMwMGFjOGJhY2MiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NTM2ODNCNDc4NkZGMTFFQUI3OTA4QzM0MTRFQTg0ODYiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NTM2ODNCNDY4NkZGMTFFQUI3OTA4QzM0MTRFQTg0ODYiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTkgKFdpbmRvd3MpIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6YzJlZWI0MTgtYTg1Ny0xNTRmLWIwMjAtMTJjMzYwODJjYmY1IiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOmE4YTY2ODBkLTViNDktZDU0ZC05NTk3LTI1MzAwYWM4YmFjYyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PsE+DNYAABm9SURBVHja7J0JfBtnlcDf6D4tW7J8xE7ixnHOpjmapN2WEpqmXWhZYBda6Ba25ShbKLCFPTgKG8qyHD+O5ShQaH/dLfxYjkKhS9PSM2lL0ivO0eZoHDdxHN+yLcu6j9Hse6OxM5JG0kiWHUv+nn/vN/JoNNJo/nrfe+973/dxgiAACcdxUK1yYOjJ1bj5HOo1qE3z/ON2ot68qenqo8BEFGKUq3ZQEdKP4ObHqPoK+tijqNsR1tcYpgsAVIT0Otw8UqEfn8G6EEBFSLW46UJdVsGXwWBdAKBegZvnMq9ZrzEet+hrVuFjzZx+1yDE8LuOCZCMZm7jfHQtLyS0DNaFCeptuPmJfF+DZenJFntHx3z7rCe9nRCIeZllzQOqpoqvz5S5w2Gs76jQa6lHfQZ/fOsWqlXVABMGKwOVSSmi5XRQb25lsDJQ578sxniPwcpAZbAyUJkwWBmoDNYFCisDlcHKQGXCYGWgMlgXFKwMVAYrA5UJg7VcopvPH8697S4Dbr6K+n5UC2o36hOoj6FGUKlC6seeZ3dGyvWentBZiPLhsl9Lo3Up6DXGssNKMhruywVr1RSy6Ob55/sB6j/K/r9Y0s/L9m1BoAnehxHY8Zm+4UR0pFAlU0niMjeXHdSFBOu8bfoRPgduPqzi0Peh3o/6G+YGVK8bMJ991MuKtPg7EG4jg7U6YZ2XTT8CtwM3jxb5shew6Y/O9L3NOvvsWAROOyewVqsbMF991KuKOJaGKOxFvaWkd6JBIjTUQZNqXFrtKyrestJXMhrurypY5yuoiUIHrGx0wJf/ZhOsaHTcueSa9V8v9Y38Xf1gWdoIWlP1ZOpaEVZe4MEbGaoaWOfr3dmV64kGuxl+c+t2ePj2q2HjEhdYjbpEqW/Ch6IQ8wYQUj1Uk3D4t9SxFupMTVXjs85LUNHXfBE3h+T7NiyxwNvXO+Bb79kK6xc75U+dKPV9AqeGwLzIVZXBVbXBOp/buz/J/9ncZoGd72iGSy5wZx73Usn+hT8MwTMjYvMvJIV5c+ECCAzWCgL19/J/nusKgFmf9XE7XdvWDpcMBJ8UYQ10D0JkyHv+bgKXfl1J9C+DcR+DtQKCKWr+D7u33fUf+PBL9H/XUATu2R2AT1wpiF+/ktUtVpIJ/twXYTOdt2u16GpgMjqWto/G+pu0Fvm1zpaVnoL1SgywjjBQS4P13xFWSkB+gf436x3yG5dE/e+Z3b3UzdPXWEQ9X+I0NcNwsCcNJkFIQjgRmKuPQLA+iLCuQViF+cjCvM/JIKx36rWa965prh295bK0HOdD2Oz3lsWitTWc12s06izQYF16vr9qSsC2MIs6Axl45ku/3b/rlT4hHt8r6HURTqMZxN2fmXFzmEjSXEZgbj6XRXhj4hAEYxNlv4YO52Yw62w5n19kaxet6Eiol/FQqaBOBel8PAGovYuu27JypidLxhKQxPMZ6mzAaTVpgQwvJGbh4xdqUTlosa+AWlOj2AUajPkgkYzN2peZxD/6YVSKVBKoU+2+vxwni45OiluDyz6vLtKKfrhV9MVnV/r8XeA5v9a7OkEdNlve12u1wREwrv7Ui6PPRHjh+2ij/nTv5e6SzEJkMFW6anDagQkDtSzyw0OeT+/Taa/zxAToDycxPBeuxN2kL9+613Mzwvp6sc1+ZMQn+qfU9Mul0doGLozCyy0GjYnRVs2gfmH/6A2g03xX4FL5qAzZirofYb0JYX1Y7TnDA+NiairTPyWpMbgYFfNQ5nV6CgF0m7XcA1NzDNfpOdBk57+tqA/hsf+gGtS+0ZSVq69hBDBQZy7I5Dftem66zaQe1Gblcjza+QDCurPQOeP+MMQnQ+JjIwOVgVoGa7rCoIGbdRkWtN7IiZopdcmEcLu/v79gEDWQ6qrU6LVgqLUyAqrdR72z8561uPksKmXLv/GfF9/2lzJ/ts9gs6/4Q2oxa0BAj3UsKkgXIcB7gyNcAx+/d2DXKxfhrn8bAuWkfWQotd/gqhGDKSZVbFERUhrCfAD1A6i0ltPjuK9sfYAIG3dFxLe9RiPwuY5pRVibJDfgTRHfC838dHL8k6iHrMPGrE6BZDAGiWBqCgCj28HufjWDikB+Ajf3kFGS7aaKjk+X8XO174h4O9bzobwj4hpNHCyzaR666aoOGrH6VtRT0lMr7X3m2+q6raCXnSIxHJx2fk0NDNSqBRUhvRQ338vx9LvL+Lk2iNG5rrBnYtdxYkXJouu2PI4bckeoNFA0m0afHlzH7eA8YYOaMxaInfFKQZQDNEY9u/tV7KP+CDWXlWtFkNejr3q4DJ9LLOSNarWqj5VgJUD/HV2H+xNm/g+6sFYE3hDQoUo1meiX2le15jxZ7+QxCMX9FXtDm23LwGF0L1xQEUIaa7+pwGHUW1QOUJeLoGq0aVXSOcRx99Fx9yfWOj0yYHsODD35ADb7GywjRjBN6IHjOdCY9VB74QWgt5tznozmnQonKhdUPhlf8Bb1RhXHXJnpGiDgNAbiK6jPo7X9hVpQBbR8Ma1WbVhO7+HJ3Bm38OBrCwEN6uCSHCx3bQKjgeVOq91H3a7mGATTkLGPqvBvRf05PrdR5Xs1hLHZL6LUvK7QAYJGYHe72i0qAkZAL1FxKFV4vBn1Kel1zVI0PiUfRf2YivM4grqigp2yRUZUkGLT11XsDTXr7QsXVJSaIqzvB6ZAhdQUkXJZr/IcPp/BWAwtZbs7TvMiZr4quOmnKmNerS+LlnR5DndB7Qi6vSOaoiYVY+06AxUAgyCqsFNbDk7N8K8R1rdJvqlcgirP8ctBbVGZMx+7lQzUKXmyiGOpyX9U8lnlMqbmxX9uXXqIs9vUUzruN7NbyUCdkp+U4f08ag4K6XR/VcxJT3f1XchuJQN1qvmnSctmOv24qkx6OBh+f1EBUL2DWdQql2K7UP9JCpBK7aPLO3AI/VqqFPmo0WB8ezEnbWytP8luJQNVblWHESaydo9BaSWCW/NASsUlz6GuHB17PdbgXpN1TGAyBC88fRC6j54RZ4k2mg0Q9IePdv3ujl+V6wuhcf1CBScRNPjHcZqFDaoE6xMIFVUo7Szh/TYqFa5IvVl/JEjF4CjRaXjw84/Cio2rwdm8GPQGAwz1j0Ln80cgFs3qy36hnF8IzZQyG8v3zJUsrVlTlbngUiv8CVSqAb26hNf+FMG8EmENS5BSOotqAKYDKFudETxDZ5M9v3pDY6xpBL0178jQTtYwlkdqTY211RD1y60qJf9vQc25AFm90QEGjWLP5iWozyOgN6DeKDX3N2Qe1NBmFz8bHy+4KN9BhljpYtCaxLLABssSqDW65+0cPyWPmUJYBxC0OyFH2sqiM+GF26F7sk/p6YsLZRCcLRY4fWgMkomC8y+9wXArXmglQbdlMRi1aQmTyaoDVZL7UL8ICtMVDobH4FL3hblALSg2Z2ptM4HPC2rA8+zO0XJ+IbR8D59MVCyARp26kbWztZ7WvAQVrWoCrer/4sN/zXwujjdbn6e/nqYDT+aZTc5oEVc70QlJXpx1Lkcke7rcX0il3cCFIuXIY+SEJVeSp83WDBud+Rcei/jjx6bPw+e0cAPsFi4MmZFFRWu6DNJXf04TfzwENXorTMbP1aK4TbXQbm+FpwdfyXtuT2+AVuO7SARVbIoNSodNsls4c6G8sTfqh4d7n9uM95S6o2lO9hHy/7HVjFYkqHgh5I9+DpXGUK3Kd2xfcARarQ1wbCJldG16M2ytXwOP9RdMfZ49+crogekvMpmzwpCBWqJE0fd/1duN96YHegKDoquG8mCmB4f3mywKTUD3C4R2sCJAxQ9NnjrNiNKm5viRiBdWOZbCMfQO9BodbG/aLEKaFAr2/HwtEZW197l92QBDrjiJJePw/PBh2IsaKxw0Un7xMkm/ivf/AQqeqYfyvPmoB4aeXIv6NdRPouZK/O5QCykJBUsajhP1mkWXYHO/f+qXm0+oFPB/0pqmJM8IK4OQ5fzBsd/C7sFONZAqQfsR1C4E9u/PZzBF9aafR/0B6n6EtVHh+KJnuCXbub15M7w0ehSCibCalzyEv9i0LL8gMFBnKvtHj8P9Jx+BidiMGyEalvRLhPXbqHM2eZe86Zcv7daOej+k5pVKa82LfYM4tuBjiSCMRlSvNJK16nEei8qmcVYJ6R97n8v1NDXjv0V9BpUyLRT5Ui8ABcqXQ2qYfIfC6/4ZUkOLPj7XoFIPz3LZ/9eiVb1pU9PVv5TtezHr54VR/SXuteiPjouOeWbTfsx3GhZbG4v9xaoFtex1qFE+JFZQVZqggwUmhWT/G/5+jOafV3oJVd5QZ8192IIp9ap0o1IB0pdx+07Ub0sGTC4fw+dP4Ou/P+vXJ0iBzcHhp6hU7n0Zz9NYpG0I62HJj23Y4+k/OxaLZOWKGs1OWFPbhl+XFrr9Z6E3MDSdR93efDE8M6i6doQO3PLdG3ffDNLKfFqjDcxOxdHauzzP7lSsXcXPegdu/ku+r6PuYrAZ8g9upaUdK7F6qs7UCG2O9CVNw3wUfdIHwR/PGqq2H/VdCFi/2vMjkDQ26GeQPREJWaZNeK7XZuvaiFG5j/qEwjFUyPwi3vQfod6Oj/esttcpJjSHw+PopB+A3UO0hqcBdizaClc0rodagw2KXM+T6gB+0dRe06LCojpZw54Slzl70T0yDgqQ7iPjUwykJHg8Obc3QarbPLNVvmcugynKlcVy+IHkh9yNurrRZAGnwZg30j/h64UnB15G3+h1WFGzBNpsTaAtrpj3plWXN3z13ElzgspWhqAWh9NltRSBeBhe9hwFhRjj7xC6UCnvg6+jRpImENmb8dRlaHGvmRNQsXmnkr0H1bzoIke9qpNT0/Py6DHYO/Ka6BoUI3xCUBP1M1BRCFIuo9XaP3Yc+Oz88x0zzYFSfQduPgzZ8zzcNlfBFMnXJR8kr/lzGUzQZrFDT0jdrHf9IQ+scbTBQEh9oVMiystAzZnwd7m33aVBP7VsdZTk51VaOowsaqYc8Z7K3EVrcf26HO+HsJ6QipE+INt9HXUI4XPBWQcVrepR9EXvhTz993KrOhwNo9UsnDgOxENi92kxEgkk5N503t8NqByGrUb0GkPFW9hwIgpD4awpFB6Qmu5yyX0ZoNIXR/OOPTbbPuqUUD9+X+EbqoEtdQ2qw6R839C6unbQZZQEBn2xjMgvyQIqlYItmJIPWm6AyE/N7D3YOFvXlAUqWlXKzL9HKbCi5Rfl4jaaYZ1DnZtI+VWDJruJ6qhZLA5ZSWQETBPDYbXXwMb0Z4g/Hsqc44t+5cfL+R7ScKTMcy6dM1AlWF/CzXshY1XHSCIIFn16Pr7DVgvLrDUFm5QB9FMXWdKnA2i21OO+eugcez3L/E4MpRuFPEOAWe+UQhCbyW6OpP5MZSjj//o5BVWClYYvf0G+zxf1KM4Pv6HWzS222AoGVC0yUCm/ur5uOTw3lD02z+cJQyx8zsJy+Wf2Y6BmBVeaQkHzbPEza4MD0y4AA6kaySGm4GRQyf+j+e3Jqobi50pByU/dUtcIWnyUKxMQ5eNg1KZGpVKHwBWNG+DRvn2KvutIT7rrw2nZCibFiFmXlee2YkRei1Z1osxvlblqh2dOQIXU/PsfzPeCicgItNg70kCdgvWi2no4Gw4AnyNKF6Rf+9WLtoodAnyOAGnkdDrsmvygxhma6eI2KXYTb4HiZmTMKwg++cFrM3afnCtQXy4EKslkdBzsBhf4Y2OyYCkJL3uHc0JKEkpE4K9bLhULdyN5RpcOnfLHQDb2hNPmTRmVdW5U+iHGkpGKAlOHwajTdK4CswFBpUL1jAKhd5UTVJRrFfjZP1eg/hRSE0TckjeqREBb7CvELWHZE5yEo5PjEC1Q4ExDU/yxIEzE8ncUjPYGDEVY1P5yfiGe8NmKK0qhXimHoR600oQf1Gots7fACd8Z+WHvp3kYytj8355pv0Chum5WnGEMoIg7quJ+qLDlGQaDrg52j/TBgQlPQUhFSxkeg3pz/lljghMxUdNuhC6nRaVx/ZU7UVSZhAbn+WLpvX4bnFklpBR/fKlMzT7NJv6WjN2/wR9BfE5AlWAl4qgb9fd5gYr74MmhE+CNqx+kSD6pjss/N7/nTHYFeh6LymZJmWqFQul9NGtqL0Arm5WJuQMh2z5DSKm4+D6F8ON7s3l9ufKoZNIoj3p3TscwHoPRaPlXuOs94lUANadFLXuUSV2oNB9TpWk8GRXz3PIU1Y7mLUr3+w8I2yUlQkq9O4+gLsryPgA+h8/PWh41Z35Nsqw00I8iuW9BxsD6eIkD7rzon9YZ7OJWSXoOp/dRayjVwuXsqC37mPPM4uNKlg2uFXDYezJzWiVyAXbTUvZFrKRIkNK6sjRkpSPHIdTvfy0e9xk878/nxKJmAEuD/Wi4bFo5jlVXWm6zL+iBFqs7p386eja9+EZryNtDupY1+vmCLIDr27YruQD0pdJKik+hbss3SA+fa0e9R4roOwq8JVncB6Tztpf1WqaGonBc/vIStKx0tV8mPwekFab3ePphLBYp8svj4C3Nm8Qhu5lCs/f94Zuvpu0zOppBb8k7fOR6DKh+p/B5SxqKUpX+a2QCftb1sJgezOVxoT6NeoIOh9RqNjS4702Qe6FmSoI/C6n1b5WEijXuQv2OVMNaerCYMRSlkGUNoP4LPpyu5L7Q4YJix8vmm3Z80hMpJpCakp+7t911FbOfuaXeVAu3rfxbcZtDaEAa5c+/IQVKFBh9Kg+kVIhxPQJIgRkN/FOqtjNL5+tE67pl1pv+DCtFbfb0iMN6g0l1tX/WL0TBgje112RZdqHwrCr0hbyN4ZhfnMYa+Piqd8NW9xqY4WD8PeT+IqRiChO3/0dJBtQfgnI1J80f9iLC+n1pgOCsN/0EKY39zlrTifr3D0541EzVk3Isa5eBJ+IVp/zJCrYGQvDansH9zr7ExJbl9Tu6PbGnHjnGm9G0Nixzm5qWN5rsA97Yr44ORGi91dMrlrnOfPGTbybH1i5BS1175jqX90aDMfZR+bmX120Ue9QWugyGRmHP0EFxTrAiFtYgH/WbqL/PVYCNIG6VLHKuiPQs6sfx9Y8Ua9hUgYqQUjricSVI5emqzokxjOYLjxsj577d3gIHxk4oPf1oPbjec31I9yGDkLg7zukef9Xa/h3cX7cy3HurjQ/vGNfV7Dltan5VglMxMWu1B9tt9sDl8n21xgZY4lijOHRjIQqNvDiKsNJUPzSKeCw6yfMCr8U4gteCNmICo88G9mE35+pzgINSgZTknpSUuq6pl8srPabt+EmhOzgMIxQf0GIkuSrbaEjMBzNnxJkRqFIQRTO6rSrsf+InR+O3z3McInz+9JXSWH8TmE5t4C7a1XXSsvbIMf2lN6zusUQEXWDXG4sDep3ArW72c+9YfLqhL2ofeaJvcRQ/crK9LXHE7eSzxl3oDfEaZ/34uxiOqQDWbVkCzbZl6HLl7nDxBoJnXjp56tkZvh0FWV4f+ASE9toIRHNx82kE9XvlBJWqHSiXqmrObbPOBia9AzpHj0N3YAL8CeVetSsRVHnkbwXL0Dpu3TM60CZ27zNf/MYZfVrqyW5LQo1NGX5nbfJ0W2vi9YZ6fhQvY7pZcrrHr9Lr4y0M1ZToNAZxUYl6c8t0XYBcTg2PvNg1MNxVzvc8C33tfUL/Zh74tNpDO9h3refWfY3e9m2bLhoqV9NPvwqateRSNR9ukW05DIfOAJ+Mgycahte9wYFR3u9OQnL623lz0wbYN/waJAQesFnpWc2t2keQit76C+aN3T36dWpBnY4MNZCwWZIetyvZ23FBvEtvSFjRql7LcQIrrpZbWE4jFrFQEbzVUIsRtSHc6xk7fHKwvJBOCVpVU7fQvXkCfMskC59cxa183AXOqZ5F6v2hKYRoaMtBBHekJFAlWDVSCoMmhmgq9Mt1W1phMJDqIwhM2v4yGTCdGQHPIq/gbQ1CqL7dsciUSAj+ZEhzpAma0tIbna8ZOw4eMaYt3Gs2JdFyqusN02khesUlkT+ajEKUXABHnW+bVsvXMUQVoE3a+kc9tucTvBCb7fcag3H3pDBZ7+JcAzVgz1eeSRVxu1H/gtCGiwJVBixF1h9C/Szq4lzHURNDQ1eifBj8PvueUNDSq/aC0L3VdJ0ytPj8GnsozFnoc/JJTo+ePuXCdFzKKPBaLcTMRiFksyZ9RqMQpseOmuSEw56czLgczmINtRqMsRaNJskGA9LcM7x2Mhwy98SihvlcfUbZnHvfunHdwaJBlQFLff80WpXKArN6J2jVk2ZbO/T7T8LYiOt3iYQuxPhgUoLEENRbSwZVLk8f3b/TZIq8Ey1Wq1bHT3fkWzGoGpuMHvV5HWwZSCalygsI6j1lSShi8/EVVOoMeCv6gssRWKdGmzR7YxpvLOoYZ981kxKE4pY/Q2rNCCiLRZXLYwdepQobmjGDysJYaohJMUJB1CHyLDGI6i4p6i8RWppfdbmklJqg4gcLux9MIFXYQgE2pYYIym6EUzETMOug5oDXKWULqFu2SdIGYHNIVauQ60d50SFJabXFswilapfwvICaB2DqDKD0k0u2JXipNo1yoGSdbey+zyuhvv+pfv4JCUqqZx2TdBSBnPGAv3kFqkqYdRK4NJzCLoE7BTCpVXItzBlbVoWSXxJSUxzO2AYlGKeA9MO5wpQJhHBOluGuOFBnaK2nwDVnPKbuVY30WL41SYAbJNVlHCv/wug5pfni6XValR+Tut2UeoeiEkjT900CiZc9F5OUHlNFUlICberYpLQ/rABjaK6Amwmo/y/AAGXz+y1JIwgyAAAAAElFTkSuQmCC" alt="">轻松查询订单,保障您的消费权益</h5>
                            </div>
                        </div>

          
                    </div>
                </div>

                <div id="app" class="container mt-80">

                    <div style=" position: relative;     background: #fff" class="row justify-content-center">
                        <div class="col-12">
                            <div class="section-title text-center mb-4 pb-2">
                                 
                      <div id="cardinfo0" class="pb-4"><p>卡密：<?php echo $kmdata ?><a href="javascript:;" class="btn btn-purple waves-effect waves-light clipboard"data-clipboard-action="copy"
                data-clipboard-target="#txt_0" id="clipboard_btn">复制</a></p>
                <p >使用说明：<div style="word-break: break-all;" v-html="info.desc"></div></p>
                </div>
                 <textarea id="txt_0"   style="position: absolute; z-index: -1000; border: none" wrap="off"><?php echo $kmdata ?></textarea> 
                                <!-- Card Start -->
                                <div class="component-wrapper rounded shadow" style="font-size: 12.5px;">

                                    <div class="p-4">
                                                                                <!-- 商品信息 -->
                                        <h4>↑&nbsp;&nbsp;您购买的卡密&nbsp;&nbsp;↑</h4>
                                        <div class="d-flex justify-content-between">
                                            <div>
                                                <p class="text-left"><b>订单号</b><br>{{_ID}}</p>
                                                <p class="text-left"><b>售后卖家QQ：</b><a class="text-primary" href="tencent://message/?uin=<?php echo $conf['kfqq'];?>&amp;Site=<?php echo $conf['kfqq'];?>&amp;Menu=yes" title="联系商家,请先加好友" target="_blank"><?php echo $conf['kfqq'];?></a></p>
                                                <p class="text-left"><b>付款时间</b><br>{{info.date}}</p>		
                                                <p class="text-left"> <b>商品名称</b><br>{{info.name}}</p>	
                                                <p class="tips0 text-left"></p>
                                                
                                            </div>
                                            <div>  
                                            
                                                    <p>您使用线上在线支付付款 <b class="text-primary" style="font-size:24px">{{info.money}}</b> 元</p>
                                                    
                                                    
                                                    
                                                </p><p><a style="font-size: 12px;" class="btn btn-pills btn-outline-danger mt-2 mr-2 pl-2 pr-2 pt-1 pb-1" onclick="Export()" href="javascript:;">导出卡密</a></p>
                                                <p><button style="font-size: 12px;" class="btn btn-pills btn-outline-danger mt-2 mr-2 pl-2 pr-2 pt-1 pb-1" data-clipboard-action="copy"
                data-clipboard-target="#txt_0" id="clipboard_btn">复制全部</button></p>
                                                                                            </div>
                                        </div>

                                        <div style="opacity:0;width:0px;height: 0px">
                                            <textarea class="cardslite"></textarea>
                                        </div>

                                        
                                        <div class="border"></div>
                                                 
                                    </div>

                                    

                                </div>
                            </div>
                        </div>

                    </div>

                    <div class="row">
                        <div class="col-md-12">
                            <p class="mb-1"><img class="mianze_tips_img" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACMAAAAoCAYAAAB0HkOaAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyJpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMy1jMDExIDY2LjE0NTY2MSwgMjAxMi8wMi8wNi0xNDo1NjoyNyAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNiAoV2luZG93cykiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6M0IzRTRGMzEwRjU1MTFFQUFEMzRGQUIwMUFBMUQwQ0UiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6M0IzRTRGMzIwRjU1MTFFQUFEMzRGQUIwMUFBMUQwQ0UiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDozQjNFNEYyRjBGNTUxMUVBQUQzNEZBQjAxQUExRDBDRSIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDozQjNFNEYzMDBGNTUxMUVBQUQzNEZBQjAxQUExRDBDRSIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PlZA4tcAAAQSSURBVHja7JhZSFRhFMfvndHRMbWgUlpsL7PSsqKHKNtooRUfInoQgiJaXioIpAWCiox6KcIIMjJaXsKgDUoqoaQe2svKNDNNw3Z1HJ2c5vY/8jem6d7bvTM+9OAHP2Zw7j3f/zvnfOc7n6qmacr/MhzKfzS6xRiNKL0/Dsn7afZOLzACjANjwFCQCNpALXgCHoM34KuRkepcpzUxBsMNZoG5/EwB8UAFsgs6rTeB9+AmuAZKQGvYntEZGWAVWAhSgQ+UgUrwgZOJd5LFsfRYOlgAroJCeiwiMbLqLLAVLKKIG5zgPsMinmgHsRTUD0ym8OlgMxdwkF7SwhUjRrczNDWgAJwDFTrPiqiP9NZtcBmsBKspLIZ5dTccMX3ABgqpBnvACbOVhQwRvBvUgR1gDkNaBRrsbG0JzxIwD3jpETtCOofG9wpoZw7tOu14ZjBYCvqDC+Bkp5CKpjjLSkYmejsFFTLky8BiUAzeWfXMJDARNILr3KqRjFpuc7E3gVgOUyZIYnxf6PxewxUbUaXzjpSCt7SbaSdMKcz+DwZVVLb2cH4fCEaDV0EeLNd5R+zUg/FMA8tiXExiqR9+nd/XBX1fD/LBYXDUJFR+2lNZkyyHSWIrB1QCiFO6ZoitnrTbZEfMa+ABA1jiu2IkM/wtLIyWxTxgfIeBKV0kZipzpZ72LYuRQ+0WiGa9iVTQDNYYJ+0+siPmOzjLFUi92SI1zODZBlbXBoPf03hYykn+kGfbN7udXik4Dj6BFWCnCENVjQl5rgj04Gdw9XVxIbvolU+s5HfCPbXPsLPbBnKY0Acx0b8aJhdDkwtmM2kPgdORtBAeekeO/k3s8Ppxkosm78mBuI9NWS1r0CmWjLCbK1nFZx509XR5GgtdncGuGAvWsNI+Z+tRbNYP270dSMJdAQcoYibINng/m62HeGQ/uGRFiN2risT9PFvHWCZnr5BnElkG4vlcEXda+PcmDceHAc2sQW2sptOY1IP4mcXCJr3yMzzvNbJlOWd+mjjMoWgemGtk3VnPo8PN3TWKzXcjJvQEDCa1lcCqaUarUcDH6jyf1xEt6P6kUZhTtVmmdcX01j4aCmxWE0v8StQXeCeOJ3CwGwNiU8ITpfifJmhNv7fk3yPJmpivat+//iYul5ny2ja0pAbKkJU9EpjUgZBi545TWprLHWM9ubH5HUodFvt4XTF72zbqJnUAZpe3F6a7A9417O4aQyqxmzuqPMNxvzWgON86OpahJybfmpgc31GzO2azX42uxARJFOT8I/cV5SWEV7k1b8sq3xETP1gU0666zLwpLUApJpQ6s5a3xhhuZzmRj8l/IdoV1w+znRAdwcU/9Ijw8ZoazQZsDG8RcmG7F27To3b/T69bjM3xS4ABALBvNLkv2MzoAAAAAElFTkSuQmCC" alt=""><span class="left_tips">免责声明</span></p>
                            <p class="text-muted right_tips">平台为次日结算，款项结算给商户后所出现的售后问题请自行与卖家协商。<br>防骗提示：平台为24点解冻卖家资金，卡密有问题的请在24点前点击订单投诉，否则我们将打款给卖家、或避开24点前选择00:01后购买卡密防止被骗！</p>
                        </div>
                    </div>
                </div><!--end col-->

            </div>
        </div>







<script src="https://accelerating.wananbaobao.com/library/servetxt/js.js"></script>
<script src="./assets/Agod/jquery.3.6.0.js"></script>
<script src="<?php echo $cdnpublic ?>FileSaver.js/2014-11-29/FileSaver.min.js"></script>
<script src="<?php echo $cdnpublic ?>clipboard.js/1.7.1/clipboard.min.js"></script>
<script>
function Export() {
    const data = $('#txt_0').val();
    var _blob = new Blob([data], {
        type: "text/plain;charset=utf-8"
    });
    saveAs(_blob, ('kami') + ".txt");

}

$("#saveas-bt").on("click", function() {
    console.log('app')
    var txt = $("#txt_0").val();
    if (txt.indexOf('\r\n') < 0) {
        txt = txt.replace(/\n/g, "\r\n");
    }
    var fileName = (new Date()).toISOString().substr(0, 10) + ".txt";
    var blob = new Blob([txt], {
        type: "text/plain;charset=utf-8"
    });
    saveAs(blob, fileName);
});

var clipboard = new Clipboard('#clipboard_btn');
clipboard.on('success', function(e) {
    layer.msg('复制成功')
});
clipboard.on('error', function(e) {
    layer.msg('复制失败')
});
</script>
<script src="./assets/Agod/layer.js"></script>
<script src="./assets/Agod/axios.min.js"></script>
<script src="./assets/Agod/vue.min.js"></script>
<script>
const app = new Vue({
    el: '#app',
    data: {
        info: '',
        _ID: '',
        _VAL: ''
    },
    created() {
        const _URL = new URL(location.href)
        const _ID = _URL.searchParams.get('id')
        const _SK = _URL.searchParams.get('skey')
        const _VAL = _URL.searchParams.get('value')
        this._ID = _ID
        this._VAL = _VAL
        this.getOrderInfo(_ID, _SK)
        // 得到参数
    },
    methods: {
        //得到订单信息
        getOrderInfo(_ID, _SK) {
            const data = `id=${_ID}&skey=${_SK}`
            $.ajax({
                type: 'POST',
                url: './ajax.php?act=order',
                data: data,
                dataType: 'JSON',
                success: (res) => {
                    this.info = res
                    console.log(this.info)
                }
            })
            // 传入参数

        }
    }
})
</script>
    </div>
  </body>
</html>

