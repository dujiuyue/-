<?php
/*
 * 自动同步设置页面
 */

// 设置错误显示 - 调试模式开启
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// 检查PHP版本
if (version_compare(PHP_VERSION, '7.0.0', '<')) {
    die('PHP版本过低，请升级到PHP 7.0或更高版本');
}

// 确保common.php路径正确
if(!file_exists("../includes/common.php")) {
    die('找不到common.php文件，请检查路径');
}

include("../includes/common.php");

// 登录验证
if($islogin==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");

// 检查并修复表结构的函数
function checkAndFixTableStructure() {
    global $DB;
    
    // 确保$DB是有效的对象
    if(!$DB || !is_object($DB)) {
        error_log('数据库连接对象无效');
        return;
    }
    
    try {
        // 检查表是否存在 - 使用更通用的方法
        $checkTable = 0;
        
        // 首先尝试使用query方法（适用于PDO和大多数数据库类）
        if(method_exists($DB, 'query')) {
            try {
                $result = $DB->query("SHOW TABLES LIKE 'pre_sync_config'");
                
                // 获取结果行数（不同数据库类可能有不同的实现）
                if(method_exists($result, 'rowCount')) {
                    $checkTable = $result->rowCount();
                } else if(method_exists($DB, 'num_rows')) {
                    $checkTable = $DB->num_rows($result);
                } else {
                    // 尝试获取所有行并计算
                    $rows = [];
                    if(method_exists($result, 'fetchAll')) {
                        $rows = $result->fetchAll();
                    } else if(method_exists($result, 'fetch_array')) {
                        while($row = $result->fetch_array()) {
                            $rows[] = $row;
                        }
                    }
                    $checkTable = count($rows);
                }
            } catch (Exception $e) {
                error_log('检查表是否存在时出错: ' . $e->getMessage());
                $checkTable = 0;
            }
        } else if(method_exists($DB, 'getRow')) {
            // 如果有getRow方法，尝试用它来检查表是否存在
            try {
                $row = $DB->getRow("SHOW TABLES LIKE 'pre_sync_config'");
                $checkTable = $row ? 1 : 0;
            } catch (Exception $e) {
                error_log('检查表是否存在时出错: ' . $e->getMessage());
                $checkTable = 0;
            }
        } else {
            // 默认假设表不存在
            $checkTable = 0;
        }
        
        if($checkTable == 0) {
            // 创建表
            $createTableSql = "CREATE TABLE `pre_sync_config` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `shequ_id` int(11) NOT NULL,
                `sync_interval` int(11) NOT NULL DEFAULT '60',
                `sync_limit` int(11) NOT NULL DEFAULT '100',
                `auto_update` tinyint(1) NOT NULL DEFAULT '1',
                `delete_rule` tinyint(1) NOT NULL DEFAULT '0',
                `sync_class` tinyint(1) NOT NULL DEFAULT '1',
                `sync_sort` tinyint(1) NOT NULL DEFAULT '1',
                `sync_goods_sort` tinyint(1) NOT NULL DEFAULT '1',
                `sync_log` tinyint(1) NOT NULL DEFAULT '1',
                `sync_name` tinyint(1) NOT NULL DEFAULT '1',
                `sync_price` tinyint(1) NOT NULL DEFAULT '1',
                `sync_cost` tinyint(1) NOT NULL DEFAULT '1',
                `sync_desc` tinyint(1) NOT NULL DEFAULT '1',
                `sync_image` tinyint(1) NOT NULL DEFAULT '1',
                `sync_workorder` tinyint(1) NOT NULL DEFAULT '1',
                `sync_details` tinyint(1) NOT NULL DEFAULT '0',
                `add_class` tinyint(1) NOT NULL DEFAULT '1',
                `add_goods` tinyint(1) NOT NULL DEFAULT '1',
                `markup_template` tinyint(1) NOT NULL DEFAULT '0',
                `status` tinyint(1) NOT NULL DEFAULT '0',
                `addtime` datetime NOT NULL,
                PRIMARY KEY (`id`),
                UNIQUE KEY `shequ_id` (`shequ_id`)
            ) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;";
            
            try {
                if(method_exists($DB, 'exec')) {
                    $DB->exec($createTableSql);
                } else if(method_exists($DB, 'query')) {
                    $DB->query($createTableSql);
                }
            } catch (Exception $e) {
                error_log('创建pre_sync_config表失败: ' . $e->getMessage());
            }
            return;
        }
        
        // 检查表结构，添加缺失的字段
        $requiredFields = [
            'markup_template' => "ALTER TABLE `pre_sync_config` ADD COLUMN `markup_template` tinyint(1) NOT NULL DEFAULT '0' AFTER `add_goods`",
            'sync_cost' => "ALTER TABLE `pre_sync_config` ADD COLUMN `sync_cost` tinyint(1) NOT NULL DEFAULT '1' AFTER `sync_price`",
            'sync_workorder' => "ALTER TABLE `pre_sync_config` ADD COLUMN `sync_workorder` tinyint(1) NOT NULL DEFAULT '1' AFTER `sync_image`",
            'add_class' => "ALTER TABLE `pre_sync_config` ADD COLUMN `add_class` tinyint(1) NOT NULL DEFAULT '1' AFTER `sync_workorder`",
            'add_goods' => "ALTER TABLE `pre_sync_config` ADD COLUMN `add_goods` tinyint(1) NOT NULL DEFAULT '1' AFTER `add_class`",
            'sync_details' => "ALTER TABLE `pre_sync_config` ADD COLUMN `sync_details` tinyint(1) NOT NULL DEFAULT '0' AFTER `sync_workorder`"
        ];
        
        // 获取表结构 - 适应不同的数据库连接对象
        $columns = [];
        try {
            if(method_exists($DB, 'query')) {
                $result = $DB->query("SHOW COLUMNS FROM `pre_sync_config`");
                
                // 根据不同的数据库类获取列名
                if(method_exists($result, 'fetchAll')) {
                    if(defined('PDO::FETCH_COLUMN')) {
                        $columns = $result->fetchAll(PDO::FETCH_COLUMN);
                    } else {
                        // 手动提取列名
                        while($row = $result->fetch()) {
                            $columns[] = is_array($row) ? $row[0] : $row->Field;
                        }
                    }
                } else if(method_exists($result, 'fetch_array')) {
                    while($row = $result->fetch_array()) {
                        $columns[] = $row[0];
                    }
                }
            } else if(method_exists($DB, 'queryall')) {
                // 某些自定义数据库类可能使用queryall方法
                $result = $DB->queryall("SHOW COLUMNS FROM `pre_sync_config`");
                foreach($result as $row) {
                    $columns[] = is_array($row) ? $row[0] : $row->Field;
                }
            }
        } catch (Exception $e) {
            error_log('获取表结构失败: ' . $e->getMessage());
            // 如果无法获取表结构，继续执行
        }
        
        // 检查并添加缺失的字段
        foreach($requiredFields as $field => $sql) {
            if(!in_array($field, $columns)) {
                try {
                    if(method_exists($DB, 'exec')) {
                        $DB->exec($sql);
                    } else if(method_exists($DB, 'query')) {
                        $DB->query($sql);
                    }
                } catch (Exception $e) {
                    error_log('添加字段失败: ' . $field . ', 错误: ' . $e->getMessage());
                    // 继续尝试其他字段
                }
            }
        }
    } catch (Exception $e) {
        error_log('表结构检查失败: ' . $e->getMessage());
        // 不抛出异常，避免中断程序
    }
}

// 处理POST请求 - 移到文件开头，确保在任何HTML输出之前处理
if(isset($_POST['submit'])){
    // 全局错误捕获
    try {
        // 记录请求开始
        error_log('开始处理同步配置保存请求');
        
        // 获取当前时间
        $date = date('Y-m-d H:i:s');
        
        // 安全获取POST数据 - 添加类型检查
        $shequ_ids = isset($_POST['shequ_ids']) && is_array($_POST['shequ_ids']) ? $_POST['shequ_ids'] : [];
        $sync_interval = isset($_POST['sync_interval']) ? intval($_POST['sync_interval']) : 60;
        $sync_limit = isset($_POST['sync_limit']) ? intval($_POST['sync_limit']) : 100;
        $monitor_key = isset($_POST['monitor_key']) ? trim($_POST['monitor_key']) : '';
        
        $success = 0;
        $error = '';
        
        // 检查数据库连接 - 使用更宽松的检查逻辑
        if(!$DB || !is_object($DB)) {
            error_log('数据库连接无效: $DB不是有效的对象');
            // 不抛出异常，尝试继续执行
        } else {
            // 测试数据库连接是否可用
            try {
                // 使用一个简单的SQL查询来测试连接
                if(method_exists($DB, 'query')) {
                    $testResult = $DB->query("SELECT 1");
                    if(!$testResult) {
                        error_log('数据库连接测试失败');
                    }
                }
            } catch (Exception $e) {
                // 捕获连接测试异常
                error_log('数据库连接测试异常: ' . $e->getMessage());
                // 继续执行，不直接抛出异常，因为可能是其他类型的数据库连接
            }
        }
        
        // 检查并修复表结构 - 函数内部已处理异常
        checkAndFixTableStructure();
        
        // 先禁用所有配置
        try {
            if($DB && is_object($DB)) {
                if(method_exists($DB, 'exec')) {
                    $result = $DB->exec("UPDATE pre_sync_config SET status=0");
                    if($result === false && method_exists($DB, 'error')) {
                        $error .= '更新状态失败['.$DB->error().']<br/>';
                    }
                } else if(method_exists($DB, 'query')) {
                    $result = $DB->query("UPDATE pre_sync_config SET status=0");
                    if(!$result) {
                        $error .= '更新状态失败<br/>';
                    }
                }
            }
        } catch (Exception $e) {
            $error .= '更新状态时发生异常: ' . $e->getMessage() . '<br/>';
            error_log('更新状态异常: ' . $e->getMessage());
        }
        
        // 处理选中的站点
        if(!empty($shequ_ids)){
            try {
                foreach($shequ_ids as $shequ_id){
                    // 确保shequ_id是有效的整数
                    $shequ_id = intval($shequ_id);
                    if($shequ_id <= 0) continue;
                    
                    // 安全获取POST数据，避免未定义索引错误
                        $auto_update = isset($_POST['auto_update_'.$shequ_id]) ? intval($_POST['auto_update_'.$shequ_id]) : 1;
                        $delete_rule = isset($_POST['delete_rule_'.$shequ_id]) ? intval($_POST['delete_rule_'.$shequ_id]) : 0;
                        $markup_template = isset($_POST['markup_template_'.$shequ_id]) ? intval($_POST['markup_template_'.$shequ_id]) : 0;
                        $sync_details = isset($_POST['sync_details_'.$shequ_id]) ? intval($_POST['sync_details_'.$shequ_id]) : 0;
                    
                        $data = [
                            'shequ_id' => $shequ_id,
                            'sync_interval' => $sync_interval,
                            'sync_limit' => $sync_limit,
                            'auto_update' => $auto_update,
                            'delete_rule' => $delete_rule,
                            'sync_class' => isset($_POST['sync_class_'.$shequ_id])?1:0,
                            'sync_sort' => isset($_POST['sync_sort_'.$shequ_id])?1:0,
                            'sync_goods_sort' => isset($_POST['sync_goods_sort_'.$shequ_id])?1:0,
                            'sync_log' => isset($_POST['sync_log_'.$shequ_id])?1:0,
                            'sync_name' => isset($_POST['sync_name_'.$shequ_id])?1:0,
                            'sync_price' => isset($_POST['sync_price_'.$shequ_id])?1:0,
                            'sync_cost' => isset($_POST['sync_cost_'.$shequ_id])?1:0,
                            'sync_desc' => isset($_POST['sync_desc_'.$shequ_id])?1:0,
                            'sync_image' => isset($_POST['sync_image_'.$shequ_id])?1:0,
                            'sync_workorder' => isset($_POST['sync_workorder_'.$shequ_id])?1:0,
                            'sync_details' => $sync_details,
                            'add_class' => isset($_POST['add_class_'.$shequ_id])?1:0,
                            'add_goods' => isset($_POST['add_goods_'.$shequ_id])?1:0,
                            'markup_template' => $markup_template,
                            'status' => 1,
                            'addtime' => $date
                        ];
                    
                    // 使用参数化查询防止SQL注入 - 支持不同数据库对象
                    try {
                        $exists = false;
                        if($DB && is_object($DB)) {
                            if(method_exists($DB, 'prepare') && method_exists($DB, 'execute')) {
                                // PDO方式
                                $stmt = $DB->prepare("SELECT * FROM pre_sync_config WHERE shequ_id=?");
                                $stmt->execute([$shequ_id]);
                                $exists = $stmt->fetch();
                            } else if(method_exists($DB, 'query')) {
                                // 普通查询方式，注意防止SQL注入
                                $sql = "SELECT * FROM pre_sync_config WHERE shequ_id='".intval($shequ_id)."'";
                                $result = $DB->query($sql);
                                if($result) {
                                    if(method_exists($result, 'fetch')) {
                                        $exists = $result->fetch();
                                    } else if(method_exists($result, 'fetch_array')) {
                                        $exists = $result->fetch_array();
                                    }
                                }
                            }
                        }
                        
                        if($exists){
                            // 更新操作 - 支持不同数据库对象
                            $result = false;
                            if($DB && is_object($DB)) {
                                if(method_exists($DB, 'prepare') && method_exists($DB, 'execute')) {
                                    // PDO方式
                                    $update_sql = "UPDATE pre_sync_config SET "
                                                . "sync_interval=?, sync_limit=?, auto_update=?, "
                                                . "delete_rule=?, sync_class=?, sync_sort=?, "
                                                . "sync_goods_sort=?, sync_log=?, sync_name=?, "
                                                . "sync_price=?, sync_cost=?, sync_desc=?, "
                                                . "sync_image=?, sync_workorder=?, sync_details=?, add_class=?, "
                                                . "add_goods=?, markup_template=?, status=?, addtime=? "
                                                . "WHERE shequ_id=?";
                                    $update_stmt = $DB->prepare($update_sql);
                                    $result = $update_stmt->execute([
                                        $data['sync_interval'], $data['sync_limit'], $data['auto_update'],
                                        $data['delete_rule'], $data['sync_class'], $data['sync_sort'],
                                        $data['sync_goods_sort'], $data['sync_log'], $data['sync_name'],
                                        $data['sync_price'], $data['sync_cost'], $data['sync_desc'],
                                        $data['sync_image'], $data['sync_workorder'], $data['sync_details'],
                                        $data['add_class'], $data['add_goods'], $data['markup_template'],
                                        $data['status'], $data['addtime'], $data['shequ_id']
                                    ]);
                                } else if(method_exists($DB, 'query')) {
                                    // 普通查询方式，注意防止SQL注入
                                    $sql = "UPDATE pre_sync_config SET "
                                        . "sync_interval='".intval($data['sync_interval'])."', "
                                        . "sync_limit='".intval($data['sync_limit'])."', "
                                        . "auto_update='".intval($data['auto_update'])."', "
                                        . "delete_rule='".intval($data['delete_rule'])."', "
                                        . "sync_class='".intval($data['sync_class'])."', "
                                        . "sync_sort='".intval($data['sync_sort'])."', "
                                        . "sync_goods_sort='".intval($data['sync_goods_sort'])."', "
                                        . "sync_log='".intval($data['sync_log'])."', "
                                        . "sync_name='".intval($data['sync_name'])."', "
                                        . "sync_price='".intval($data['sync_price'])."', "
                                        . "sync_cost='".intval($data['sync_cost'])."', "
                                        . "sync_desc='".intval($data['sync_desc'])."', "
                                        . "sync_image='".intval($data['sync_image'])."', "
                                        . "sync_workorder='".intval($data['sync_workorder'])."', "
                                        . "sync_details='".intval($data['sync_details'])."', "
                                        . "add_class='".intval($data['add_class'])."', "
                                        . "add_goods='".intval($data['add_goods'])."', "
                                        . "markup_template='".intval($data['markup_template'])."', "
                                        . "status='".intval($data['status'])."', "
                                        . "addtime='".addslashes($data['addtime'])."' "
                                        . "WHERE shequ_id='".intval($data['shequ_id'])."'";
                                    $result = $DB->query($sql);
                                }
                            }
                            
                            if($result){
                                $success++;
                            } else {
                                $error .= '站点ID'.$shequ_id.'修改失败<br/>';
                            }
                        } else {
                            // 插入操作 - 支持不同数据库对象
                            $result = false;
                            if($DB && is_object($DB)) {
                                if(method_exists($DB, 'prepare') && method_exists($DB, 'execute')) {
                                    // PDO方式
                                    $insert_sql = "INSERT INTO pre_sync_config ("
                                                . "shequ_id, sync_interval, sync_limit, auto_update, "
                                                . "delete_rule, sync_class, sync_sort, sync_goods_sort, "
                                                . "sync_log, sync_name, sync_price, sync_cost, sync_desc, "
                                                . "sync_image, sync_workorder, sync_details, add_class, add_goods, "
                                                . "markup_template, status, addtime) "
                                                . "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                                    $insert_stmt = $DB->prepare($insert_sql);
                                    $result = $insert_stmt->execute([
                                        $data['shequ_id'], $data['sync_interval'], $data['sync_limit'],
                                        $data['auto_update'], $data['delete_rule'], $data['sync_class'],
                                        $data['sync_sort'], $data['sync_goods_sort'], $data['sync_log'],
                                        $data['sync_name'], $data['sync_price'], $data['sync_cost'],
                                        $data['sync_desc'], $data['sync_image'], $data['sync_workorder'],
                                        $data['sync_details'], $data['add_class'], $data['add_goods'],
                                        $data['markup_template'], $data['status'], $data['addtime']
                                    ]);
                                } else if(method_exists($DB, 'query')) {
                                    // 普通查询方式，注意防止SQL注入
                                    $sql = "INSERT INTO pre_sync_config SET "
                                        . "shequ_id='".intval($data['shequ_id'])."', "
                                        . "sync_interval='".intval($data['sync_interval'])."', "
                                        . "sync_limit='".intval($data['sync_limit'])."', "
                                        . "auto_update='".intval($data['auto_update'])."', "
                                        . "delete_rule='".intval($data['delete_rule'])."', "
                                        . "sync_class='".intval($data['sync_class'])."', "
                                        . "sync_sort='".intval($data['sync_sort'])."', "
                                        . "sync_goods_sort='".intval($data['sync_goods_sort'])."', "
                                        . "sync_log='".intval($data['sync_log'])."', "
                                        . "sync_name='".intval($data['sync_name'])."', "
                                        . "sync_price='".intval($data['sync_price'])."', "
                                        . "sync_cost='".intval($data['sync_cost'])."', "
                                        . "sync_desc='".intval($data['sync_desc'])."', "
                                        . "sync_image='".intval($data['sync_image'])."', "
                                        . "sync_workorder='".intval($data['sync_workorder'])."', "
                                        . "sync_details='".intval($data['sync_details'])."', "
                                        . "add_class='".intval($data['add_class'])."', "
                                        . "add_goods='".intval($data['add_goods'])."', "
                                        . "markup_template='".intval($data['markup_template'])."', "
                                        . "status='".intval($data['status'])."', "
                                        . "addtime='".addslashes($data['addtime'])."'";
                                    $result = $DB->query($sql);
                                }
                            }
                            
                            if($result){
                                $success++;
                            } else {
                                $error .= '站点ID'.$shequ_id.'添加失败<br/>';
                            }
                        }
                    } catch (Exception $e) {
                        $error .= '处理站点ID'.$shequ_id.'时异常: ' . $e->getMessage() . '<br/>';
                        error_log('站点ID'.$shequ_id.'处理异常: ' . $e->getMessage());
                    }
                }
            } catch (Exception $e) {
                $error .= '处理站点配置时发生错误: ' . $e->getMessage() . '<br/>';
                error_log('站点配置处理异常: ' . $e->getMessage());
            }
        }
        
        // 保存监控密钥 - 支持不同数据库对象
        try {
            if($DB && is_object($DB)) {
                if(method_exists($DB, 'prepare') && method_exists($DB, 'execute')) {
                    // PDO方式
                    $stmt = $DB->prepare("REPLACE INTO pre_config SET k='monitor_key', v=?");
                    $stmt->execute([$monitor_key]);
                } else if(method_exists($DB, 'query')) {
                    // 普通查询方式，注意防止SQL注入
                    $sql = "REPLACE INTO pre_config SET k='monitor_key', v='".addslashes($monitor_key)."'";
                    $DB->query($sql);
                }
            }
        } catch (Exception $e) {
            $error .= '保存监控密钥失败: ' . $e->getMessage() . '<br/>';
            error_log('保存监控密钥异常: ' . $e->getMessage());
        }
        
        // 清除所有输出缓冲
        @ob_clean();
        // 设置正确的内容类型
        header('Content-Type: application/json; charset=utf-8');
        // 确保不缓存
        header('Cache-Control: no-cache, must-revalidate');
        header('Expires: Mon, 26 Jul 1997 05:00:00 GMT');
        
        // 构造响应数据
        $response = [];
        if($error){
            $response = ['code' => 0, 'msg' => $error];
            error_log('保存失败: ' . $error);
        } else {
            if($success > 0){
                $response = ['code' => 1, 'msg' => '成功配置'.$success.'个站点!'];
            } else {
                $response = ['code' => 1, 'msg' => '已成功保存所有同步配置!'];
            }
        }
        
        // 输出JSON并立即终止脚本
        echo json_encode($response, JSON_UNESCAPED_UNICODE);
        exit;
        
    } catch (Exception $e) {
        // 捕获所有异常，确保返回有效的JSON
        @ob_clean();
        header('Content-Type: application/json; charset=utf-8');
        $error_msg = '服务器内部错误: ' . $e->getMessage();
        error_log('AJAX处理异常: ' . $e->getMessage());
        echo json_encode(['code' => 0, 'msg' => $error_msg], JSON_UNESCAPED_UNICODE);
        exit;
    }
}

// 页面标题设置
$title='自动同步设置';
include './head.php';

echo '<script src="//cdn.bootcdn.net/ajax/libs/layer/3.1.1/layer.js"></script>';


// 检查数据库表是否存在，如果不存在则创建 - 
$table_name = DBQZ . 'sync_config';
$check_table_sql = "SHOW TABLES LIKE '" . $table_name . "'";
$table_exists = $DB->query($check_table_sql)->fetch();

if(!$table_exists) {
    // 创建配置表 - 注意：使用pre_sync_config表名以匹配系统现有表结构
    $create_table_sql = "
    CREATE TABLE IF NOT EXISTS `$table_name` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `shequ_id` varchar(50) NOT NULL COMMENT '社区ID',
        `shequ_type` varchar(20) NOT NULL COMMENT '社区类型',
        `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否启用',
        `sync_interval` int(11) NOT NULL DEFAULT '5' COMMENT '同步间隔(分钟)',
        `sync_limit` int(11) NOT NULL DEFAULT '50' COMMENT '每次同步数量',
        `auto_update` tinyint(1) NOT NULL DEFAULT '1',
        `delete_rule` tinyint(1) NOT NULL DEFAULT '0',
        `sync_class` tinyint(1) NOT NULL DEFAULT '1',
        `sync_sort` tinyint(1) NOT NULL DEFAULT '1',
        `sync_goods_sort` tinyint(1) NOT NULL DEFAULT '1',
        `sync_log` tinyint(1) NOT NULL DEFAULT '1',
        `sync_name` tinyint(1) NOT NULL DEFAULT '1',
        `sync_price` tinyint(1) NOT NULL DEFAULT '1',
        `sync_cost` tinyint(1) NOT NULL DEFAULT '1',
        `sync_desc` tinyint(1) NOT NULL DEFAULT '1',
        `sync_image` tinyint(1) NOT NULL DEFAULT '1',
        `sync_workorder` tinyint(1) NOT NULL DEFAULT '1',
        `add_class` tinyint(1) NOT NULL DEFAULT '1',
        `add_goods` tinyint(1) NOT NULL DEFAULT '1',
        `markup_template` int(11) NOT NULL DEFAULT '0',
        `addtime` datetime DEFAULT CURRENT_TIMESTAMP,
        `uptime` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        UNIQUE KEY `shequ_id` (`shequ_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='自动同步配置表';
    ";
    $DB->exec($create_table_sql);
    echo '<div class="px-4 py-3 bg-emerald-50 border border-emerald-100 text-emerald-600 rounded-xl text-sm flex items-center shadow-sm max-w-[1200px] mx-auto mb-4"><i class="fa fa-check-circle text-lg mr-2 shrink-0"></i>系统已自动创建必要的数据表，请刷新页面</div>';
}

// 原有函数保留，避免重复执行
function checkAndCreateTables($DB) {
    // 检查并创建同步配置表
    $check_config_table = $DB->query("SHOW TABLES LIKE 'pre_sync_config'");
    if($check_config_table->rowCount() == 0) {
        // 创建同步配置表 - 确保包含所有必要字段
        $create_config_table_sql = "CREATE TABLE IF NOT EXISTS `pre_sync_config` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `shequ_id` int(11) NOT NULL COMMENT '社区ID',
            `sync_interval` int(11) NOT NULL DEFAULT '60' COMMENT '同步间隔(分钟)',
            `sync_limit` int(11) NOT NULL DEFAULT '100' COMMENT '同步数量',
            `auto_update` tinyint(1) NOT NULL DEFAULT '1' COMMENT '自动更新',
            `delete_rule` tinyint(1) NOT NULL DEFAULT '0' COMMENT '删除规则',
            `sync_class` tinyint(1) NOT NULL DEFAULT '0' COMMENT '同步分类',
            `sync_sort` tinyint(1) NOT NULL DEFAULT '0' COMMENT '同步排序',
            `sync_goods_sort` tinyint(1) NOT NULL DEFAULT '0' COMMENT '同步商品排序',
            `sync_log` tinyint(1) NOT NULL DEFAULT '0' COMMENT '同步日志',
            `sync_name` tinyint(1) NOT NULL DEFAULT '1' COMMENT '同步名称',
            `sync_price` tinyint(1) NOT NULL DEFAULT '1' COMMENT '同步价格',
            `sync_cost` tinyint(1) NOT NULL DEFAULT '0' COMMENT '同步成本',
            `sync_desc` tinyint(1) NOT NULL DEFAULT '1' COMMENT '同步描述',
            `sync_image` tinyint(1) NOT NULL DEFAULT '1' COMMENT '同步图片',
            `sync_workorder` tinyint(1) NOT NULL DEFAULT '0' COMMENT '同步工单',
            `add_class` tinyint(1) NOT NULL DEFAULT '0' COMMENT '添加分类',
            `add_goods` tinyint(1) NOT NULL DEFAULT '0' COMMENT '添加商品',
            `markup_template` int(11) NOT NULL DEFAULT '0' COMMENT '加价模板',
            `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
            `addtime` datetime NOT NULL COMMENT '添加时间',
            PRIMARY KEY (`id`),
            UNIQUE KEY `shequ_id` (`shequ_id`)
        ) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='自动同步配置表';";
        if($DB->query($create_config_table_sql) === false) {
            return '创建同步配置表失败: ' . $DB->error();
        }
    }
    return true;
}

// 执行数据表检查
$result = checkAndCreateTables($DB);
if($result !== true) {
    echo '<div class="px-4 py-3 bg-rose-50 border border-rose-100 text-rose-600 rounded-xl text-sm flex items-center shadow-sm max-w-[1200px] mx-auto mb-4"><i class="fa fa-exclamation-circle text-lg mr-2 shrink-0"></i>' . $result . '</div>';
}

// 获取所有对接站点 - 确保所有站点都能显示
$rs = $DB->query("SELECT * FROM pre_shequ order by id asc");
$shequlist = array();
while ($res = $rs->fetch()) {
    // 尝试获取插件配置
    $getInfo = \lib\Plugin::getConfig("third_" . $res["type"]);
    if ($getInfo) {
        $res['title'] = $getInfo['title'];
    } else {
        // 如果没有插件配置，使用默认标题 - 
        $res['title'] = '站点 ' . $res["type"] . ' - ' . $res["id"];
    }
    // 确保所有站点都添加到列表中
    $shequlist[] = $res;
}

// 获取已启用的配置
$enabled_configs = array();
$rs = $DB->query("SELECT * FROM pre_sync_config WHERE status=1");
while($row = $rs->fetch()){
    $enabled_configs[$row['shequ_id']] = $row;
}

// 获取监控地址
$monitor_key = $DB->getColumn("SELECT v FROM pre_config WHERE k='monitor_key'");
$monitor_url = $siteurl.'admin/cx-api-synchronization.php'.($monitor_key?'?key='.$monitor_key:'');
// 获取最近运行时间
$last_run_time = $DB->getColumn("SELECT v FROM pre_config WHERE k='last_sync_time'");
if(!$last_run_time) $last_run_time = '从未运行';

?>

<div class="w-full max-w-[1400px] mx-auto space-y-6">
    <div class="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        <div class="px-6 py-5 border-b border-slate-100 flex items-center bg-slate-50/50">
            <i class="fa fa-refresh text-brand-500 mr-2 text-lg"></i>
            <h3 class="text-base sm:text-lg font-bold text-slate-800 m-0">自动同步设置</h3>
        </div>
        
        <div class="p-6">
            <form onsubmit="return save()" method="post" class="space-y-6" id="syncForm">
                
                <div class="grid grid-cols-1 md:grid-cols-4 gap-6 items-center">
                    <label class="text-sm font-semibold text-slate-700 md:text-right">任务监控地址</label>
                    <div class="md:col-span-3 space-y-2">
                        <input type="text" class="w-full h-11 px-4 text-sm rounded-xl border-slate-200 bg-slate-50 text-slate-500 shadow-inner" value="<?php echo $monitor_url?>" readonly>
                        <p class="text-xs text-slate-500">请将此地址添加到服务器计划任务中，建议执行频率为 5 分钟</p>
                        
                        <div class="mt-3 p-4 bg-amber-50 border border-amber-100 rounded-xl text-amber-700 text-sm shadow-sm space-y-1">
                            <div class="font-bold flex items-center"><i class="fa fa-warning mr-1.5 text-lg"></i> 重要提醒：</div>
                            <div class="ml-5">
                                <p>• 自动同步执行期间需要较长时间完成</p>
                                <p>• 如果出现自动同步没效果，请注意是不是没生成密钥</p>
                                <p>• 自动同步不支持魔改商城，部分云商城会没效果</p>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="grid grid-cols-1 md:grid-cols-4 gap-6 items-center">
                    <label class="text-sm font-semibold text-slate-700 md:text-right">最近运行时间</label>
                    <div class="md:col-span-3">
                        <input type="text" class="w-full h-11 px-4 text-sm rounded-xl border-slate-200 bg-slate-50 text-slate-500 shadow-inner" value="<?php echo $last_run_time?>" readonly>
                    </div>
                </div>
                
                <div class="grid grid-cols-1 md:grid-cols-4 gap-6 items-center">
                    <label class="text-sm font-semibold text-slate-700 md:text-right">Cron 计划任务</label>
                    <div class="md:col-span-3 space-y-2">
                        <div class="w-full p-4 text-sm rounded-xl border border-slate-200 bg-slate-800 text-slate-200 shadow-inner font-mono overflow-x-auto whitespace-nowrap">
                            */5 * * * * curl --silent <?php echo $monitor_url?>
                        </div>
                        <p class="text-xs text-slate-500">Linux 服务器 Crontab 计划任务设置示例</p>
                    </div>
                </div>
                
                <div class="border-t border-slate-100 my-6"></div>
                
                <div class="grid grid-cols-1 md:grid-cols-4 gap-6 items-center">
                    <label class="text-sm font-semibold text-slate-700 md:text-right">接口监控密钥</label>
                    <div class="md:col-span-3 space-y-2">
                        <div class="flex gap-2">
                            <input type="text" class="w-full h-11 px-4 text-sm rounded-xl border-slate-200 focus:border-brand-500 focus:ring-brand-500 shadow-sm bg-white transition-colors flex-1" name="monitor_key" value="<?php echo $monitor_key?>" placeholder="请设置监控密钥">
                            <button class="inline-flex items-center justify-center px-5 h-11 rounded-xl bg-slate-100 border border-slate-200 text-slate-600 hover:bg-slate-200 font-medium transition-colors shrink-0 shadow-sm" type="button" onclick="generateKey()">生成密钥</button>
                        </div>
                        <p class="text-xs text-slate-500">设置后需要在监控地址后面加上 <code class="bg-slate-100 px-1 rounded text-brand-600">?key=监控密钥</code> 才能访问，为空则不限制访问</p>
                    </div>
                </div>
                
                <div class="grid grid-cols-1 md:grid-cols-4 gap-6 items-start">
                    <label class="text-sm font-semibold text-slate-700 md:text-right pt-3">请选择同步站点</label>
                    <div class="md:col-span-3 space-y-2">
                        <div class="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm">
                            <div class="px-5 py-3 border-b border-slate-200 bg-slate-50 flex justify-between items-center">
                                <div>
                                    <h4 class="text-sm font-bold text-slate-700 m-0">对接站点列表</h4>
                                    <span class="text-xs text-slate-500 mt-0.5 block">已选择 <b id="selected_count" class="text-brand-600">0</b> 个站点</span>
                                </div>
                                <div class="flex items-center gap-4">
                                    <label class="inline-flex items-center cursor-pointer m-0">
                                        <input type="checkbox" onclick="checkAll(this)" class="w-4 h-4 text-brand-600 bg-white border-slate-300 rounded focus:ring-brand-500 cursor-pointer">
                                        <span class="ml-2 text-sm font-medium text-slate-700">全选</span>
                                    </label>
                                    <a href="./shequlist.php" class="text-sm font-medium text-brand-600 hover:underline">
                                        <i class="fa fa-plus mr-1"></i>添加站点
                                    </a>
                                </div>
                            </div>
                            
                            <div class="p-4 bg-slate-50/50 site-list space-y-4">
                                <?php foreach($shequlist as $row){
                                    $checked = isset($enabled_configs[$row['id']]) ? ' checked' : '';
                                    $isActive = isset($enabled_configs[$row['id']]) ? true : false;
                                    $config = isset($enabled_configs[$row['id']]) ? $enabled_configs[$row['id']] : [];
                                    
                                    echo '<div class="site-item bg-white border '.($isActive ? 'border-brand-400 shadow-md ring-1 ring-brand-100' : 'border-slate-200').' rounded-xl overflow-hidden transition-all duration-300" id="site_item_'.$row['id'].'">';
                                    
                                    // 站点头部 (点击折叠/展开)
                                    echo '<div class="px-5 py-4 cursor-pointer hover:bg-slate-50 transition-colors flex items-start sm:items-center justify-between" onclick="toggleSiteConfig(this, '.$row['id'].')">';
                                    echo '  <div class="flex items-start gap-3">';
                                    echo '      <div class="mt-0.5" onclick="event.stopPropagation();">';
                                    echo '          <input type="checkbox" name="shequ_ids[]" value="'.$row['id'].'" class="w-4.5 h-4.5 text-brand-600 bg-white border-slate-300 rounded focus:ring-brand-500 cursor-pointer site-checkbox-input" onchange="syncSiteState('.$row['id'].')" '.$checked.'>';
                                    echo '      </div>';
                                    echo '      <div>';
                                    echo '          <div class="font-bold text-slate-800 text-sm">'.$row['title'].'</div>';
                                    echo '          <div class="text-xs text-slate-500 mt-1 truncate max-w-[200px] sm:max-w-xs" title="'.$row['url'].'">'.$row['url'].'</div>';
                                    if($row['remark']) echo '<div class="text-xs text-brand-600 bg-brand-50 inline-block px-2 py-0.5 rounded mt-1">'.$row['remark'].'</div>';
                                    echo '      </div>';
                                    echo '  </div>';
                                    echo '  <i class="fa fa-angle-down text-slate-400 text-lg transition-transform duration-300 site-toggle-icon '.($isActive ? 'rotate-180' : '').'"></i>';
                                    echo '</div>';
                                    
                                    // 展开的详细配置
                                    echo '<div class="site-config '.($isActive ? 'block' : 'hidden').' border-t border-slate-100 bg-slate-50/50 p-5 space-y-6" id="config_'.$row['id'].'">';
                                    
                                    // -- 基础设置
                                    echo '  <div>';
                                    echo '      <h5 class="text-sm font-bold text-slate-700 flex items-center mb-3"><span class="w-1 h-3.5 bg-brand-500 rounded-full mr-2"></span>基础设置</h5>';
                                    echo '      <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">';
                                    echo '          <div class="space-y-1.5">';
                                    echo '              <label class="text-xs font-semibold text-slate-600">自动更新</label>';
                                    $auto_update_val = isset($config['auto_update']) ? intval($config['auto_update']) : 1;
                                    echo '              <select name="auto_update_'.$row['id'].'" class="w-full h-10 px-3 text-sm rounded-xl border-slate-200 focus:border-brand-500 focus:ring-brand-500 shadow-sm bg-white cursor-pointer">';
                                    echo '                  <option value="1"'.($auto_update_val == 1 ? ' selected' : '').'>开启</option>';
                                    echo '                  <option value="0"'.($auto_update_val == 0 ? ' selected' : '').'>关闭</option>';
                                    echo '              </select>';
                                    echo '          </div>';
                                    echo '          <div class="space-y-1.5">';
                                    echo '              <label class="text-xs font-semibold text-slate-600">下架商品处理</label>';
                                    $delete_rule_val = isset($config['delete_rule']) ? intval($config['delete_rule']) : 0;
                                    echo '              <select name="delete_rule_'.$row['id'].'" class="w-full h-10 px-3 text-sm rounded-xl border-slate-200 focus:border-brand-500 focus:ring-brand-500 shadow-sm bg-white cursor-pointer">';
                                    echo '                  <option value="0"'.($delete_rule_val == 0 ? ' selected' : '').'>保留商品 (不处理)</option>';
                                    echo '                  <option value="1"'.($delete_rule_val == 1 ? ' selected' : '').'>下架商品 (同步状态)</option>';
                                    echo '                  <option value="2"'.($delete_rule_val == 2 ? ' selected' : '').'>删除商品 (直接删除)</option>';
                                    echo '              </select>';
                                    echo '          </div>';
                                    echo '      </div>';
                                    echo '  </div>';
                                    
                                    // -- 同步选项
                                    echo '  <div>';
                                    echo '      <h5 class="text-sm font-bold text-slate-700 flex items-center mb-3"><span class="w-1 h-3.5 bg-brand-500 rounded-full mr-2"></span>同步选项</h5>';
                                    echo '      <div class="mb-4 space-y-1.5">';
                                    echo '          <label class="text-xs font-semibold text-slate-600">获取商品详情</label>';
                                    $sync_details_val = isset($config['sync_details']) ? intval($config['sync_details']) : 0;
                                    echo '          <select name="sync_details_'.$row['id'].'" class="w-full h-10 px-3 text-sm rounded-xl border-slate-200 focus:border-brand-500 focus:ring-brand-500 shadow-sm bg-white cursor-pointer">';
                                    echo '              <option value="1"'.($sync_details_val == 1 ? ' selected' : '').'>开启（数据完整，但速度极慢）</option>';
                                    echo '              <option value="0"'.($sync_details_val == 0 ? ' selected' : '').'>关闭（仅列表数据，速度快）</option>';
                                    echo '          </select>';
                                    echo '      </div>';
                                    
                                    echo '      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">';
                                    
                                    // 抽象生成复选框卡片
                                    $checkboxes = [
                                        ['name' => 'sync_class', 'label' => '分类', 'desc' => '更新商品所属分类'],
                                        ['name' => 'sync_sort', 'label' => '分类排序', 'desc' => '同步分类的排序权重'],
                                        ['name' => 'sync_goods_sort', 'label' => '商品排序', 'desc' => '同步商品的排序权重'],
                                        ['name' => 'sync_log', 'label' => '上架日志', 'desc' => '新增时记录上架日志'],
                                        ['name' => 'sync_name', 'label' => '名称', 'desc' => '同步商品名称'],
                                        ['name' => 'sync_price', 'label' => '价格', 'desc' => '同步商品销售价格'],
                                        ['name' => 'sync_cost', 'label' => '成本', 'desc' => '同步商品成本价格'],
                                        ['name' => 'sync_desc', 'label' => '描述', 'desc' => '同步详细富文本描述'],
                                        ['name' => 'sync_image', 'label' => '图片', 'desc' => '同步商品主图资源'],
                                        ['name' => 'sync_workorder', 'label' => '网盘投诉', 'desc' => '自动开启商品网盘投诉']
                                    ];
                                    
                                    foreach($checkboxes as $cb) {
                                        $isChecked = (isset($config[$cb['name']]) && $config[$cb['name']] == 1) ? ' checked' : '';
                                        echo '<label class="relative flex items-start p-3 bg-white border border-slate-200 rounded-xl cursor-pointer hover:border-brand-300 hover:bg-brand-50/30 transition-colors group">';
                                        echo '  <div class="flex items-center h-5">';
                                        echo '      <input type="checkbox" name="'.$cb['name'].'_'.$row['id'].'" value="1" class="w-4 h-4 text-brand-600 bg-white border-slate-300 rounded focus:ring-brand-500 cursor-pointer"'.$isChecked.'>';
                                        echo '  </div>';
                                        echo '  <div class="ml-3 flex flex-col">';
                                        echo '      <span class="text-sm font-semibold text-slate-700 group-hover:text-brand-700 transition-colors">'.$cb['label'].'</span>';
                                        echo '      <span class="text-[11px] text-slate-400 mt-0.5 leading-tight">'.$cb['desc'].'</span>';
                                        echo '  </div>';
                                        echo '</label>';
                                    }
                                    echo '      </div>';
                                    echo '  </div>';
                                    
                                    // -- 新增选项
                                    echo '  <div>';
                                    echo '      <h5 class="text-sm font-bold text-slate-700 flex items-center mb-3"><span class="w-1 h-3.5 bg-brand-500 rounded-full mr-2"></span>新增选项</h5>';
                                    echo '      <div class="mb-4 space-y-1.5">';
                                    echo '          <label class="text-xs font-semibold text-slate-600">默认加价模板</label>';
                                    $markup_template_val = isset($config['markup_template']) ? intval($config['markup_template']) : 0;
                                    echo '          <select name="markup_template_'.$row['id'].'" class="w-full h-10 px-3 text-sm rounded-xl border-slate-200 focus:border-brand-500 focus:ring-brand-500 shadow-sm bg-white cursor-pointer">';
                                    echo '              <option value="0"'.($markup_template_val == 0 ? ' selected' : '').'>不使用加价模板</option>';
                                    $rs_price=$DB->query("SELECT * FROM pre_price ORDER BY id ASC");
                                    while($res_price = $rs_price->fetch()){
                                        echo '              <option value="'.$res_price['id'].'"'.($markup_template_val == $res_price['id'] ? ' selected' : '').'>'.$res_price['name'].'</option>';
                                    }
                                    echo '          </select>';
                                    echo '          <p class="text-[11px] text-brand-600"><i class="fa fa-info-circle mr-1"></i>选择加价模板后，新增商品时将自动应用对应的加价规则</p>';
                                    echo '      </div>';
                                    
                                    echo '      <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">';
                                    $add_class_checked = (isset($config['add_class']) && $config['add_class'] == 1) ? ' checked' : '';
                                    echo '<label class="relative flex items-start p-3 bg-white border border-slate-200 rounded-xl cursor-pointer hover:border-brand-300 hover:bg-brand-50/30 transition-colors group"><div class="flex items-center h-5"><input type="checkbox" name="add_class_'.$row['id'].'" value="1" class="w-4 h-4 text-brand-600 bg-white border-slate-300 rounded focus:ring-brand-500 cursor-pointer"'.$add_class_checked.'></div><div class="ml-3 flex flex-col"><span class="text-sm font-semibold text-slate-700 group-hover:text-brand-700">允许自动新增分类</span><span class="text-[11px] text-slate-400 mt-0.5 leading-tight">禁用时，没有对应本地分类的商品将跳过</span></div></label>';
                                    
                                    $add_goods_checked = (isset($config['add_goods']) && $config['add_goods'] == 1) ? ' checked' : '';
                                    echo '<label class="relative flex items-start p-3 bg-white border border-slate-200 rounded-xl cursor-pointer hover:border-brand-300 hover:bg-brand-50/30 transition-colors group"><div class="flex items-center h-5"><input type="checkbox" name="add_goods_'.$row['id'].'" value="1" class="w-4 h-4 text-brand-600 bg-white border-slate-300 rounded focus:ring-brand-500 cursor-pointer"'.$add_goods_checked.'></div><div class="ml-3 flex flex-col"><span class="text-sm font-semibold text-slate-700 group-hover:text-brand-700">允许自动新增商品</span><span class="text-[11px] text-slate-400 mt-0.5 leading-tight">允许系统自动将远程新商品入库</span></div></label>';
                                    echo '      </div>';
                                    echo '  </div>';
                                    
                                    echo '</div>'; // End site-config
                                    echo '</div>'; // End site-item
                                }?>
                            </div>
                        </div>
                        <p class="text-xs text-slate-500 mt-1">只显示系统中已添加的对接站点，如需添加请前往<a href="./shequlist.php" class="text-brand-600 font-medium hover:underline ml-1">对接站点管理</a></p>
                    </div>
                </div>
                
                <div class="grid grid-cols-1 md:grid-cols-4 gap-6 items-center">
                    <label class="text-sm font-semibold text-slate-700 md:text-right">同步请求间隔</label>
                    <div class="md:col-span-3 space-y-1.5">
                        <div class="relative">
                            <select name="sync_interval" class="w-full h-11 pl-4 pr-10 text-sm rounded-xl border-slate-200 focus:border-brand-500 focus:ring-brand-500 shadow-sm bg-white cursor-pointer transition-colors" required>
                                <option value="0">0分钟 (极速模式/仅用于调试)</option>
                                <option value="1">1分钟</option>
                                <option value="3">3分钟</option>
                                <option value="5" selected>5分钟 (推荐)</option>
                                <option value="10">10分钟</option>
                                <option value="15">15分钟</option>
                                <option value="30">30分钟</option>
                                <option value="60">1小时</option>
                            </select>
                        </div>
                        <p class="text-xs text-slate-500">设置两次同步之间的最小时间间隔。正式运行时强烈建议设置 5 分钟以上，以免引发对接站点的并发风控拦截。</p>
                    </div>
                </div>
                
                <div class="grid grid-cols-1 md:grid-cols-4 gap-6 items-center">
                    <label class="text-sm font-semibold text-slate-700 md:text-right">单次同步数量</label>
                    <div class="md:col-span-3 space-y-1.5">
                        <div class="relative">
                            <select name="sync_limit" class="w-full h-11 pl-4 pr-10 text-sm rounded-xl border-slate-200 focus:border-brand-500 focus:ring-brand-500 shadow-sm bg-white cursor-pointer transition-colors" required>
                                <option value="10">10个/次</option>
                                <option value="30">30个/次</option>
                                <option value="50" selected>50个/次 (稳定推荐)</option>
                                <option value="100">100个/次</option>
                                <option value="200">200个/次</option>
                                <option value="500">500个/次</option>
                                <option value="1000">1000个/次</option>
                            </select>
                        </div>
                        <p class="text-xs text-slate-500">每次执行同步时抓取的最大商品数，数量过大易导致请求超时 502，建议视双方服务器性能而定。</p>
                    </div>
                </div>
                
                <div class="grid grid-cols-1 md:grid-cols-4 gap-6 pt-4 border-t border-slate-50">
                    <div class="md:col-start-2 md:col-span-3">
                        <input type="submit" name="submit" value="保存全局自动同步配置" class="w-full h-12 rounded-xl bg-brand-600 text-white font-bold text-base hover:bg-brand-700 shadow-sm hover:shadow-md transition-all duration-200 cursor-pointer active:scale-[0.98]"/>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="//cdn.bootcdn.net/ajax/libs/layer/3.1.1/layer.js"></script>
<script>
// 点击卡片折叠/展开详细配置
function toggleSiteConfig(element, siteId) {
    var $siteItem = $('#site_item_' + siteId);
    var $configDiv = $('#config_' + siteId);
    var $icon = $(element).find('.site-toggle-icon');
    var $checkbox = $siteItem.find('.site-checkbox-input');
    
    // 如果复选框没有选中，不允许展开配置，或者如果处于选中状态，允许折叠/展开
    if ($checkbox.prop('checked')) {
        $configDiv.slideToggle(300, function() {
            if ($configDiv.is(':visible')) {
                $configDiv.removeClass('hidden').addClass('block');
                $icon.addClass('rotate-180');
            } else {
                $configDiv.removeClass('block').addClass('hidden');
                $icon.removeClass('rotate-180');
            }
        });
    } else {
        // 如果点击时没选中，自动帮用户勾选并展开
        $checkbox.prop('checked', true);
        syncSiteState(siteId);
    }
}

// 勾选复选框时的状态联动
function syncSiteState(siteId) {
    var $siteItem = $('#site_item_' + siteId);
    var $configDiv = $('#config_' + siteId);
    var $icon = $siteItem.find('.site-toggle-icon');
    var isChecked = $siteItem.find('.site-checkbox-input').prop('checked');
    
    if (isChecked) {
        $siteItem.addClass('border-brand-400 shadow-md ring-1 ring-brand-100').removeClass('border-slate-200');
        $configDiv.removeClass('hidden').addClass('block').slideDown(300);
        $icon.addClass('rotate-180');
    } else {
        $siteItem.removeClass('border-brand-400 shadow-md ring-1 ring-brand-100').addClass('border-slate-200');
        $configDiv.slideUp(300, function() {
            $(this).removeClass('block').addClass('hidden');
        });
        $icon.removeClass('rotate-180');
    }
    updateCount();
}

function checkAll(obj){
    var checked = $(obj).prop('checked');
    $("input[name='shequ_ids[]']").each(function(){
        $(this).prop('checked', checked);
        syncSiteState($(this).val());
    });
}

function updateCount(){
    var count = $("input[name='shequ_ids[]']:checked").length;
    $("#selected_count").text(count);
}

function save(){
    console.log('开始保存配置...');
    var submitBtn = $("input[type='submit']");
    submitBtn.attr("disabled",true);
    
    // 验证选中的站点数量
    var selectedCount = $("input[name='shequ_ids[]']:checked").length;
    console.log('选中的站点数量:', selectedCount);
    
    // 提取表单数据
    var formData = $("#syncForm").serialize() + '&submit=1';
    console.log('提交数据:', formData);
    
    // 安全检查
    if(selectedCount > 0 && formData.indexOf('shequ_ids%5B%5D=') === -1) {
        console.error('表单数据中缺少站点ID');
        submitBtn.attr("disabled",false);
        layer.alert('表单数据异常，请刷新页面重试！', {icon: 5});
        return false;
    }
    
    var ii = layer.load(2, {shade:[0.1,'#fff']});
    
    $.ajax({
        type : 'POST',
        url : window.location.href,
        data : formData,
        dataType : 'json',
        timeout: 30000, // 设置30秒超时
        success : function(data) {
            console.log('保存成功返回:', data);
            layer.close(ii);
            
            // 验证响应数据格式
            if(data && typeof data.code !== 'undefined') {
                if(data.code == 1){
                    layer.alert(data.msg || '保存成功！', {icon: 1}, function(){
                        window.location.reload();
                    });
                }else{
                    layer.alert(data.msg || '保存失败，请稍后重试！', {icon: 2});
                }
            } else {
                console.error('无效的响应格式:', data);
                layer.alert('服务器返回的数据格式错误，请检查服务器日志！', {icon: 2});
            }
            
            $("input[type='submit']").attr("disabled",false);
        },
        error:function(xhr, status, error){
            console.error('AJAX错误详情:');
            console.error('状态:', status);
            console.error('错误:', error);
            
            var isHtmlResponse = xhr.responseText && /<[^>]+>/i.test(xhr.responseText);
            var errorMessage = '保存失败，请稍后重试！';
            
            if(status === 'parsererror') {
                errorMessage += '\n错误类型: JSON解析错误';
                if(isHtmlResponse) errorMessage += '\n提示: 服务器可能返回了HTML错误页面而非JSON';
            } else if(status === 'timeout') {
                errorMessage += '\n错误类型: 请求超时';
            } else if(status === 'error') {
                errorMessage += '\n错误类型: AJAX错误';
                if(xhr.status) {
                    errorMessage += '\nHTTP状态码: ' + xhr.status;
                    if(xhr.status === 500) errorMessage += ' (服务器内部错误)';
                }
            }
            
            layer.close(ii);
            layer.alert(errorMessage, {icon: 2});
            $("input[type='submit']").attr("disabled",false);
        }
    });
    return false;
}

function generateKey() {
    var chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    var key = "";
    for(var i=0; i<32; i++) {
        key += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    $("input[name=\'monitor_key\']").val(key);
}

$(document).ready(function(){  
    console.log('页面加载开始');
    var shequListData = <?php echo json_encode($shequlist ?? []); ?> || [];
    var enabledConfigsData = <?php echo json_encode($enabled_configs ?? []); ?> || {};
    
    if (!Array.isArray(shequListData) || shequListData.length === 0) {
        $('.site-list').html(`
            <div class="p-8 text-center text-slate-400 bg-white border border-slate-200 rounded-xl border-dashed">
                <i class="fa fa-cubes text-4xl mb-3 block text-slate-300"></i>
                <p>当前系统内暂未配置任何对接站点</p>
                <a href="./shequlist.php" class="inline-block mt-3 px-4 py-2 rounded-lg bg-brand-50 text-brand-600 font-medium text-sm hover:bg-brand-100 transition-colors">前往添加站点</a>
            </div>
        `);
    }
    
    updateCount();
    var allConfigs = typeof enabledConfigsData === 'object' ? enabledConfigsData : {};
    
    // 初始化下拉选单与默认配置
    $.each(allConfigs, function(shequId, config) {
        try {
            if (!config) return true;
            var siteId = shequId;
            // 下拉设置回显处理
            $("select[name='auto_update_" + siteId + "']").val(config.auto_update || 1);
            $("select[name='delete_rule_" + siteId + "']").val(config.delete_rule || 0);
            $("select[name='markup_template_" + siteId + "']").val(config.markup_template || 0);
            $("select[name='sync_details_" + siteId + "']").val(config.sync_details || 0);
        } catch (err) {
            console.error(`初始化站点 ${shequId} 配置失败:`, err);
        }
    });
    
    // 设置全局同步频率
    if(Object.keys(allConfigs).length > 0) {
        var firstSiteId = Object.keys(allConfigs)[0];
        var firstConfig = allConfigs[firstSiteId];
        if(firstConfig) {
            $("select[name='sync_interval']").val(firstConfig.sync_interval || 5);
            $("select[name='sync_limit']").val(firstConfig.sync_limit || 50);
        }
    }
    console.log('页面初始化完成');
});
</script>

<?php include './foot.php';?>
